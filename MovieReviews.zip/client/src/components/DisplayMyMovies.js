import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";

const DisplayMyMovies = () => {
  const navigate = useNavigate();
  const [myMovieList, setMyMovieList] = useState([]);

  useEffect(() => {
    axios
      .get("http://localhost:8000/api/allMoviesByMe", {
        withCredentials: true,
        credentials: "include",
      })

      .then((res) => {
        console.log("Movies added by me:", res);
        setMyMovieList(res.data.myMovies);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  return (
    <div className="myMovies ">
      <h5 className=" p-5 bg-dark">Movies added by me:</h5>
      <table class="table table-bordered bg-dark text-warning">
        <thead>
          <tr>
            <th scope="col">Title</th>
            <th scope="col">Poster</th>
            <th scope="col">Director </th>
          </tr>
        </thead>
        <tbody>
          {myMovieList.map((movie, index) => (
            <tr>
              <td>
                <div key={index}>
                  <Link to={`/oneMovie/${movie._id}`} className="d-block mb-2">
                    <>
                      <td className="">
                        <div className="">{movie.title}</div>
                      </td>
                    </>
                  </Link>
                </div>
              </td>
              <td>
                <div key={index}>
                  <img src={movie.boxArt} className="col col-4" />
                </div>
              </td>
              <td>
                <div key={index}>{movie.director}</div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default DisplayMyMovies;
