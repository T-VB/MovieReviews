import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams, Link, useNavigate } from "react-router-dom";
import LikeButton from "./LikeButton";
import DisplayReviews from "./DisplayReviews";

const OneMovie = () => {
  const { id } = useParams();
  const [oneMovie, setOneMovie] = useState({});
  const navigate = useNavigate();
  useEffect(() => {
    axios
      .get(`http://localhost:8000/api/oneMovie/${id}`, {
        withCredentials: true,
        credentials: "include",
      })
      .then((res) => {
        console.log(res);
        console.log(res.data);
        setOneMovie(res.data);
      })
      .catch((err) => console.log(err));
  }, [id]);

  const deleteHandler = () => {
    axios
      .delete(`http://localhost:8000/api/deleteMovie/${id}`, {
        withCredentials: true,
        credentials: "include",
      })
      .then((res) => {
        navigate("/displayAll");
      })
      .catch((err) => {
        console.log(err);
      });
  };
  return (
    <div className="bg-secondary">
      <div className="bg-dark">
        <h3 className="mt-1 mb-3 bg-dark text-warning p-4">{oneMovie.title}</h3>
        <img src={oneMovie.boxArt} className="col col-2 mx-auto" />
        <p className="mt-4 text-success">Director: {oneMovie.director}</p>
        <p className="text-success">Genre: {oneMovie.genre}</p>
        <p className="text-success">Release Year: {oneMovie.releaseYear}</p>
        <p className="text-success">Rating: {oneMovie.rating}</p>
        <p className="text-success">Box Office: {oneMovie.boxOffice}</p>

        <Link className="p-4" to="/createReview">
          Add Review
        </Link>
        <button className="btn btn-danger" onClick={deleteHandler}>
          Delete Movie
        </button>

        <Link className="p-4" to={`/updateMovie/${oneMovie._id}`}>
          Edit Movie
        </Link>
        <LikeButton></LikeButton>
      </div>
      <div className="pt-5 text-warning bg-dark">
        <h4>Reviews:</h4>
        <DisplayReviews></DisplayReviews>
      </div>
    </div>
    //***FOR LOOP TO GET ALL REVIEWS FROM DB***
    //for one review in all reviews, if post id is equal to user id..

    // const OneReview = () => {
    //   const { id } = useParams();
    //   const [oneReview, setOneMovie] = useState({});
    //   useEffect(() => {
    //     axios
    //       .get(`http://localhost:8000/api/oneReview/${id}`, {
    //         withCredentials: true,
    //         credentials: "include",
    //       })
    //       .then((res) => {
    //         console.log(res);
    //         console.log(res.data);
    //         setOneReview(res.data);
    //       })
    //       .catch((err) => console.log(err));
    //   }, [id])};

    // //     <div>
    //       {/* <p className="text-info">Reviews: {oneReview.movieReview}</p> */}
    //     </div>
    //   </div>
    //);
  );
};

export default OneMovie;
