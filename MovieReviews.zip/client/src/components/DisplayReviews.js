import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";

const DisplayReviews = () => {
  const navigate = useNavigate();
  const [reviewList, setReviewList] = useState([]);

  useEffect(() => {
    axios
      .get("http://localhost:8000/api/allReviews", {
        withCredentials: true,
        credentials: "include",
      })

      .then((res) => {
        console.log(res);
        setReviewList(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  return (
    <div className="d-flex flex-column justify-content-around flex-wrap text-center p-5">
      {reviewList.map((review, index) => (
        <div key={index}>
          <Link to={`/oneReview/${review._id}`} className="d-block mb-2">
            {review.movieReview} | {review.movieName} | {review.addBy}
          </Link>
        </div>
      ))}
    </div>
  );
};

export default DisplayReviews;
