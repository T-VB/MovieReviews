import React, { useState, useEffect } from "react";
import axios from "axios";
import { useParams, useNavigate } from "react-router-dom";

const CreateReview = (props) => {
  const { reviewList, setReviewList } = props;
  //const [errors, setErrors] = useState({});
  const [movieName, setMovieName] = useState("");
  const [movieReview, setMovieReview] = useState("");
  const [addedBy, setAddedBy] = useState("");
  const navigate = useNavigate();
  const { id } = useParams();

  useEffect(() => {
    axios
      .get(`http://localhost:8000/api/oneMovie/${id}`, {
        withCredentials: true,
      })
      .then((res) => {
        console.log(res);
        setMovieName(res.data.movieName);
      })
      .catch((err) => {
        console.log(err);
      });
  }, [id]);

  const submitHandler = (e) => {
    e.preventDefault(); //prevents default action of page refresh and state clear, once button is clicked

    axios
      .post(
        "http://localhost:8000/api/createReview",
        {
          movieName,
          movieReview,
          addedBy,
        },
        { withCredentials: true, credentials: "include" }
      )
      .then((res) => {
        console.log(res);
        console.log(res.data);
        //navigate(`/oneMovie/${movie._id}`);
        navigate("/displayAll");
        //**upon a successful res/post request, setState back to "", which clears form
        setReviewList([...reviewList, res.data]);
        setMovieName("");
        setMovieReview("");
        setAddedBy("");
      })
      .catch((err) => {
        console.log(err);
        console.log(err.response);
        console.log(err.response.data);
        //setErrors(err.response.data.errors);
      });
  };

  return (
    <div className="pt-5 pb-5 mt-1 bg-secondary">
      <div className="col-3 mx-auto bg-warning">
        <h1 className=" p-4 d-flex justify-content-around text-warning bg-dark">
          Add a Review:
        </h1>
        <form className="p-4" onSubmit={submitHandler}>
          <label className="form-label">Movie Title:</label>
          <input
            onChange={(e) => setMovieName(e.target.value)}
            className="form-control"
            type="text"
            //value={movieName}
          />

          {/* {errors.movieName ? (
            <p class="text-danger">{errors.movieName.message}</p>
          ) : null} */}

          <label className="form-label">Review:</label>
          <textarea
            onChange={(e) => setMovieReview(e.target.value)}
            className="form-control"
            type="text"
          />
          {/* {errors.movieReview ? (
            <p class="text-danger">{errors.movieReview.message}</p>
          ) : null} */}
          <label className="form-label">Added by:</label>
          <input
            onChange={(e) => setAddedBy(e.target.value)}
            className="form-control"
            type="text"
          />
          {/* {errors.addedBy ? (
            <p class="text-danger">{errors.addedBy.message}</p>
          ) : null} */}

          <button className="mt-3 btn btn-info ">Submit</button>
        </form>
      </div>
    </div>
  );
};

export default CreateReview;
