const mongoose = require("mongoose");

const ReviewSchema = new mongoose.Schema(
  {
    movieName: {
      type: String,
      //required: [true, "Title is required!"],
    },
  },
  {
    movieReview: {
      type: String,
      //required: [true, "Review is required!"],
    },
  },
  {
    addedBy: {
      type: String,
      //required: [true, "added by is required!"],
    },
  },
  //^create user object (addedBy) in review

  { timestamps: true }
);

const Review = mongoose.model("Review", ReviewSchema); //creates a new Collection in our db. mongoose.model is a function that takes two parameters (name of collection, name of schema)

module.exports = Review; //export Review model so we can access in other files
