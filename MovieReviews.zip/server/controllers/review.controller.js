const Review = require("../models/review.model");
const jwt = require("jsonwebtoken");
const SECRET = process.env.SECRET_KEY;
const Movie = require("../models/movie.model");

module.exports = {
  createReview: (req, res) => {
    const review = new Review();
    review.movieName = req.body.movieName;
    review.movieReview = req.body.movieReview;
    review.user = req.body.user;
    review.save();
    const user = jwt.verify(req.cookies.userToken, SECRET);
    Review.create({ ...req.body, user: user }) //creates from client input(incoming request)
      .then((newReview) => {
        User.findOne({ movieName: review.movieName }, (err, user) => {
          if (user) {
            user.reviews.push(review);
            user.save();
            //console.log(newReview);
            res.json(newReview);
          }
        });
      }) //^returns a promise so start with .then, convert to json
      .catch((err) => {
        console.log(err);
        res.status(400).json(err);
      });
  },
  getAllReviews: (req, res) => {
    Review.find() //creates from client input
      .then((allReviews) => {
        res.json(allReviews);
      }) //^returns a promise so start with .then, convert to json
      .catch((err) => {
        console.log(err);
        res.status(400).json(err);
      });
  },
  // getAllReviewsByMovie: (req, res) => {
  //   Review.findById({ _id: req.params.id }) //creates from client input
  //     .then((allReviews) => {
  //       res.json(allReviews);
  //     }) //^returns a promise so start with .then, convert to json
  //     .catch((err) => {
  //       console.log(err);
  //       res.status(400).json(err);
  //     });
  // },

  getOneReview: (req, res) => {
    Review.findOne({ _id: req.params.id }) //creates from client input. "Movie" comes from the model
      .then((oneReview) => {
        //console.log(review);
        res.json(oneReview);
      }) //^returns a promise so start with .then, convert to json
      .catch((err) => {
        console.log(err);
        res.status(400).json(err);
      });
  },
  deleteReview: (req, res) => {
    Review.deleteOne({ _id: req.params.id })
      .then((deletedReview) => {
        console.log(deletedReview);
        res.json(deletedReview);
      })
      .catch((err) => {
        console.log(err);
        res.status(400).json(err);
      });
  },
};
