const User = require("../models/user.model");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const SECRET = process.env.SECRET_KEY;

module.exports = {
  registerUser: async (req, res) => {
    try {
      const newUser = await User.create(req.body);
      user.username = req.body.username;
      user.email = req.body.email;
      user.password = req.body.password;
      user.myMovies = req.body.myMovies;
      user.save();
      const userToken = jwt.sign(
        { _id: newUser._id, email: newUser.email },
        SECRET
      );
      res
        .status(201)
        .cookie("userToken", userToken, {
          httpOnly: true,
          expires: new Date(Date.now() + 90000),
        })
        .json({ successMessage: "User registered", user: newUser });
    } catch (error) {
      res.status(400).json(error);
    }
  },

  getUser: async (req, res) => {
    User.findOne({ username: req.params.username })
      .populate("reviews")
      .then((result) => {
        res.json(result);
      })
      .catch((error) => {
        res.status(400).json({ error });
      });
  },

  updateUser: (req, res) => {
    console.log("updatedUser");
    const user = jwt.verify(req.cookies.userToken, SECRET);
    console.log("We are here", user._id);
    User.findOneAndUpdate({ _id: user._id }, req.body, {
      new: true,
      //runValidators: true,
    })
      //}) //^req.params.id comes from what is passed in through the url via routes
      //^req.body is what we are wanting to update
      .then((updatedUser) => {
        console.log("this worked", updatedUser);
        res.json(updatedUser);
      })
      .catch((err) => {
        console.log("not working", err);
        res.status(400).json(err);
      });
  },

  loginUser: async (req, res) => {
    console.log("Testing");
    //check to see if email is in database
    const user = await User.findOne({ email: req.body.email });
    console.log(user);
    if (user === null) {
      //if the user's email is not found/not match... render error message
      console.log("User not found");
      res.status(400).json({ error: "Invalid email/password" });
      return;
    }

    try {
      //if the user email is found, continue to compare pw
      const isPasswordValid = await bcrypt.compare(
        req.body.password,
        user.password
      );
      console.log(isPasswordValid);
      if (!isPasswordValid) {
        //if the user's pw does not match records.. render error message
        res.status(400).json({ error: "Invalid email/password" });
      } else {
        //if both req.body email and pw match data in db, create json web token

        const userToken = jwt.sign(
          { _id: user._id, email: user.email },
          SECRET
        );
        res
          .status(201)
          .cookie("userToken", userToken, {
            httpOnly: true,
            expires: new Date(Date.now() + 90000),
          })
          .json({ successMessage: "User logged in", user: user });
      }
    } catch (error) {
      res.status(500).json({ error: "Invalid email/password" });
    }
  },
  logoutUser: (req, res) => {
    //clear cookie from the browser
    res.clearCookie("userToken");
    res.json({ success: "User logged out" });
  },
};
